<?php
$_['heading_title'] = '<b>UniShop2</b> - Звернення покупців';
$_['text_extension'] = 'Модулі';
$_['text_success'] = 'Налаштування успішно збережено!';
$_['text_edit'] = 'Налаштування віджета "Звернення покупців"';
$_['text_status_1'] = 'Нове';
$_['text_status_2'] = 'В обробці';
$_['text_status_3'] = 'Завершене';
$_['text_no_results'] = 'Список звернень порожній';
$_['column_type'] = 'Тип обігу';
$_['column_name'] = 'Ім\'я';
$_['column_phone'] = 'Телефон';
$_['column_mail'] = 'E-mail';
$_['column_date'] = 'Дата додавання';
$_['column_status'] = 'Статус';
$_['column_action'] = 'Дія';
$_['entry_status'] = 'Статус';
$_['entry_sort_order'] = 'Сортування';
$_['entry_width'] = 'Ширина';
$_['entry_limit'] = 'Показувати останніх';
$_['error_permission'] = 'Помилка: У вас недостатньо прав для управління даним модулем!';
?>