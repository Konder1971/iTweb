<?php
$_['heading_title'] = '<b>UniShop2</b> - List of manufacturers';
$_['text_module'] = 'Modules';
$_['text_success'] = 'The settings module updated!';
$_['text_edit'] = 'Edit the module';
$_['entry_view_resolution'] = 'To hide the module on the permissions under:';
$_['text_res_768'] = '768 pixel';
$_['text_res_992'] = '992 pixels';
$_['text_res_1200'] = '1200 pixels';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'You have no right to control this module!';
?>