<?php
$_['heading_title'] = '<b>UniShop2</b> - Wall categories';
$_['text_module'] = 'Modules';
$_['text_success'] = 'The settings module updated!';
$_['text_edit'] = 'Edit the module';
$_['entry_category_list'] = 'Show categories:';
$_['entry_show_column'] = 'The number of blocks in a row:';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'You have no right to control this module!';
$_['entry_name'] = 'The title of the module in the admin:';
$_['entry_module_title'] = 'The module title on display:';
?>