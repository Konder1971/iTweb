<?php
$_['heading_title'] = '<b>UniShop2</b> - Категорії новин';
$_['text_module'] = 'Модулі';
$_['text_success'] = 'Налаштування успішно змінено!';
$_['text_edit'] = 'Редагування';
$_['entry_status'] = 'Статус';
$_['error_permission'] = 'У вас недостатньо прав для внесення змін!';
?>