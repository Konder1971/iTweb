<?php
$_['heading_title'] = '<b>UniShop2</b> - Банер';
$_['text_extension'] = 'Модулі';
$_['text_success'] = 'Налаштування модуля успішно змінено.';
$_['text_edit'] = 'Редагування';
$_['entry_name'] = 'Ім\'я модуля';
$_['entry_banner'] = 'Банер';
$_['entry_dimension'] = 'Dimension (W x H) and Resize Type';
$_['entry_help'] = 'На відміну від стандартного модуля банера, цей модуль виводить картинки в ряд, якщо він в основному контенті сторінки і одну під одною, якщо в колонках.<br />
Ширина картинок банерів підлаштовується автоматично в залежності від кількості картинок в банері. Рекомендується не більше шести картинок.';
$_['entry_height'] = 'Height';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'Попередження: у вас недостатньо прав для редагування модуля!';
$_['error_name'] = 'Module Name must be between 3 and 64 characters!';
$_['error_width'] = 'Width required!';
$_['error_height'] = 'Height required!';
?>