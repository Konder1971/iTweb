<?php
$_['heading_title'] = '<b>UniShop2</b> You watched';
$_['text_module'] = 'Modules';
$_['text_success'] = 'The module settings successfully updated!';
$_['text_edit'] = 'Edit the module';
$_['entry_name'] = 'The name of the module in the admin:';
$_['entry_title'] = 'The name of the module in the window:';
$_['entry_limit'] = 'Show products:';
$_['entry_width'] = 'The image size of product:';
$_['entry_height'] = 'Height';
$_['entry_view_type'] = 'To display the products grid instead of the carousel:';
$_['entry_status'] = 'Status:';
$_['error_permission'] = 'You have no right to control the module!';
$_['error_name'] = 'The module name must be between 3 and 64 characters!';
$_['error_width'] = 'You specify the Width!';
$_['error_height'] = 'You need to specify the Height!';
?>