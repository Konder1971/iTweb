<?php
$_['heading_title'] = '<b>UniShop2</b> - News category';
$_['text_module'] = 'Modules';
$_['text_success'] = 'Settings successfully changed!';
$_['text_edit'] = 'Edit';
$_['entry_status'] = 'Status';
$_['error_permission'] = 'You are not allowed to make changes!';
?>