<?php
// Heading
$_['heading_title']    = '<b>UniShop2</b> - Категории новостей';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_edit']        = 'Редактирование';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У вас недостаточно прав для внесения изменений!';