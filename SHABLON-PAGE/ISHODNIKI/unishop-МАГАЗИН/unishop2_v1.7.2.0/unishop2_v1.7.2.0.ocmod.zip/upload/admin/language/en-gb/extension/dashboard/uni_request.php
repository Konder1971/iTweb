<?php
$_['heading_title'] = '<b>UniShop2</b> - Treatment buyers';
$_['text_extension'] = 'Modules';
$_['text_success'] = 'Settings saved successfully!';
$_['text_edit'] = 'The settings of the widget "treatment of customers"';
$_['text_status_1'] = 'New';
$_['text_status_2'] = 'In the treatment of';
$_['text_status_3'] = 'Completed';
$_['text_no_results'] = 'The case list is empty';
$_['column_type'] = 'The type of treatment';
$_['column_name'] = 'Name';
$_['column_phone'] = 'Phone';
$_['column_mail'] = 'E-mail';
$_['column_date'] = 'Date added';
$_['column_status'] = 'Status';
$_['column_action'] = 'Action';
$_['entry_status'] = 'Status';
$_['entry_sort_order'] = 'Sorting';
$_['entry_width'] = 'Width';
$_['entry_limit'] = 'Show latest';
$_['error_permission'] = 'Error: you Have insufficient rights to manage that module!';
?>