<?php
$_['text_login'] = 'Authorization';
$_['text_login2'] = 'Login';
$_['text_login3'] = 'Authorize!';
$_['text_login4'] = 'Log in with your username and password';
$_['text_register'] = 'Registration';
$_['text_register2'] = 'To register';
$_['text_register3'] = 'Already registered?';
$_['text_forgotten'] = 'I forgot password';
$_['text_confirm'] = 'I agree to the terms of the document';
$_['text_appruv'] = 'Your account has been successfully created and is awaiting confirmation. After confirmation You can log on to the website using Your email address and password.';
$_['error_popup_login'] = 'Incorrect username or password.';
?>