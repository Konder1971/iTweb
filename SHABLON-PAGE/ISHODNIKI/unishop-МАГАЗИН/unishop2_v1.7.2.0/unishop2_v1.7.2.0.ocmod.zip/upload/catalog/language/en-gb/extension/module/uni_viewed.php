<?php
$_['heading_title'] = 'You watched';
$_['text_tax'] = 'Without tax:';
?>