<?php
$_['heading_title'] = 'Brands';
?>