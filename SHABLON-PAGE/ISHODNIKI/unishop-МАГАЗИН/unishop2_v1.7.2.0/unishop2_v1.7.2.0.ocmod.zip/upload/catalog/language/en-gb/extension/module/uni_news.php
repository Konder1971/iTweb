<?php
$_['heading_title'] = 'News';
$_['text_more'] = 'Read more...';
$_['text_posted'] = 'Added:';
$_['buttonlist'] = 'View all';
?>