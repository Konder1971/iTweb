<?php
$_['heading_title'] = 'Бренди';
?>