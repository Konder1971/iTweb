<?php
$_['heading_title'] = 'Відгуки про товар';
$_['text_all_reviews'] = 'Детальніше...';
?>