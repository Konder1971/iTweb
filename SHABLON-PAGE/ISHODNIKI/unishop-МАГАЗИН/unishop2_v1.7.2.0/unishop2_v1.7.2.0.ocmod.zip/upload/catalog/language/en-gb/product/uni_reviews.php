<?php
$_['heading_title'] = 'Customer reviews';
$_['text_empty'] = 'There is no reviews!';
?>