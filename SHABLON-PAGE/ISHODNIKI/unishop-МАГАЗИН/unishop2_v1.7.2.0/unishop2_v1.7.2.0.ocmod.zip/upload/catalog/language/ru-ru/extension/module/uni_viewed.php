<?php
// Heading
$_['heading_title'] = 'Вы смотрели';

// Text
$_['text_tax']      = 'Без налога:';