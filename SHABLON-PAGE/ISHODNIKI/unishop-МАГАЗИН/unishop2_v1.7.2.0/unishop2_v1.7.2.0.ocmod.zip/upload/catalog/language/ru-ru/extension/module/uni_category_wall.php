<?php
$_['text_all_cats'] = 'Все категории';
?>