<?php
// Heading
$_['heading_title'] = 'Отзывы покупателей';

// Text
$_['text_empty'] = 'Нет отзывов!';
