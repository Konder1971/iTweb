<?php
$_['heading_title'] = 'Product reviews';
$_['text_all_reviews'] = 'Read more...';
?>