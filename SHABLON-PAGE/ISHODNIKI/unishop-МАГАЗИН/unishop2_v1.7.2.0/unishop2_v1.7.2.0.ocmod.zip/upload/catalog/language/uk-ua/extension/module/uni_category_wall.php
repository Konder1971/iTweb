<?php
$_['text_all_cats'] = 'Всі категорії';
?>