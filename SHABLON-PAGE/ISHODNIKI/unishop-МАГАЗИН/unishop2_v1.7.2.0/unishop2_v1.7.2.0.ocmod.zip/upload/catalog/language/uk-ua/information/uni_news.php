<?php
$_['heading_title'] = 'Новини';
$_['text_error'] = 'Поки немає жодної новини';
$_['text_error_news'] = 'На жаль новину не знайдено';
$_['text_error_category'] = 'На жаль категорія новин не знайдено';
$_['text_more'] = 'Читати далі...';
$_['text_posted'] = 'Додано: ';
$_['text_viewed'] = '(%s переглядів) ';
$_['text_related_product_title'] = 'Пов\'язані товари';
$_['button_news'] = 'Повернутися до списку новин';
$_['button_continue'] = 'Продовжити';
$_['text_date_asc'] = 'Дата (старі > свіжі)';
$_['text_date_desc'] = 'Дата (свіжі > старі)';
$_['text_name_asc'] = 'Заголовок (А - Я)';
$_['text_name_desc'] = 'Заголовок (Я - А)';
$_['text_viewed_asc'] = 'Перегляди (починаючи з низьких)';
$_['text_viewed_desc'] = 'Перегляди (починаючи з високих)';
?>