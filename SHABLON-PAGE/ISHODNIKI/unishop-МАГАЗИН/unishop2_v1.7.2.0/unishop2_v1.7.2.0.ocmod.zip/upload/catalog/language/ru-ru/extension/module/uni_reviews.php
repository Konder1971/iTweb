<?php
$_['heading_title']  = 'Отзывы о товаре';
$_['text_all_reviews']  = 'Подробнее';