<?php
$_['heading_title'] = 'Новини';
$_['text_more'] = 'Читати далі...';
$_['text_posted'] = 'Додано:';
$_['buttonlist'] = 'Посмотреть все';
?>