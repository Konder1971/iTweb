<?php
$_['text_all_cats'] = 'All categories';
?>