<?php
$_['heading_title'] = 'Вы смотрели';
$_['text_tax'] = 'Без податку:';
?>