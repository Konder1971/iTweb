<?php
$_['heading_title']   	= 'Новости';
$_['text_more']  		= 'Читать далее';
$_['text_posted'] 		= 'Добавлено:';
$_['buttonlist']     	= 'Посмотреть все';
?>
