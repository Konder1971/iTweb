$(function() {
	if(uniJsVars.showmore && $('.product-layout').length && $('.pagination .active').next().find('a').length) {
		$('.pagination').before('<div class="show-more" style="margin:0 0 20px;text-align:center"><button type="button" class="show-more__btn btn btn-lg btn-default"><i class="show-more__icon fa fa-sync-alt"></i><span>'+uniJsVars.showmore_text+'</span></button></div>');
		
		let pagination = $('.pagination'),
			products = $('.products-block'),
			showmoreBtn = $('.show-more__btn'),
			showmoreIcon = $('.show-more__icon');
		
		showmoreBtn.on('click', function() {
			let url = pagination.find('.active').next().find('a').attr('href'),
				scrollPos = $('html, body').scrollTop();
			
			if(typeof(url) == 'undefined' || url == '') return;
			
			if (document.location.protocol == 'https:') url = url.replace('http:', 'https:');
	
			$.ajax({
				url: url,
				type: 'get',
				dataType: 'html',
				beforeSend: function() {
					showmoreIcon.addClass('spin');
				},
				success: function(data) {
					let result = $(data);
						
					result.find('.product-thumb').hide();
					
					products.append(result.find('.products-block').html()).find('.product-thumb').fadeIn('slow');
					pagination.html(result.find('.pagination').html());
			
					if(!pagination.find('.active').next().find('a').length) {
						$('.show-more').hide();
					}
					
					showmoreIcon.removeClass('spin');
					uniSelectView.init();
					window.history.pushState('', '', url);
				},
				complete: function(){
					$('html, body').scrollTop(scrollPos);
				}
			});
		});
	}

	if(uniJsVars.ajax_pagination && $('.products-block').length) {
		$(document).on('click', '.pagination a', function(e) {
		
			e.preventDefault();
			
			let pagination = $('.pagination'),
				products = $('.products-block'),
				url = $(this).attr('href');
			
			if (document.location.protocol == 'https:') url = url.replace('http:', 'https:');
	
			$.ajax({
				url: url,
				type: 'get',
				dataType: 'html',
				beforeSend: function() {
					$('html body').append('<div class="full-width-loading"></div>');
				},
				complete: function() {
					uniSelectView.init();
					scroll_to('.products-block');
				},
				success: function(data) {
					products.html($(data).find('.products-block').html());
					pagination.html($(data).find('.pagination').html());
				
					if(!pagination.find('.active').next().find('a').length) {
						$('.show-more').hide();
					} else {
						$('.show-more').show();
					}
				
					$('.full-width-loading').remove();
				
					window.history.pushState('', '', url);
				}
			});
		});
	}
});